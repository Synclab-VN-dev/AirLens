# Samsung Display eLearning Design System

## Context
This design system is built for **Samsung Display's internal eLearning platform** — training modules (deployed via Articulate Rise 360) that teach sales, install and support teams about Samsung's professional display product lines: indoor/outdoor LED signage (The Wall, IEA/IAC/IFR/ISC/IHC/IEF series, Micro LED), SmartView / SmartThings casting features, and digital-signage buying guidance. This is a B2B/internal training product, not a consumer-facing site.

**Sources provided:**
- `eLearning/` — a mounted local folder containing:
  - `index.html`, `heading.html`, `rise_360_reusable_template.html`, `samsung_e_learning_module.html` — four near-identical drafts of a reusable Rise-360 module template (hero + two alternating image/text sections + an AI-generation interactive tool wired to the Gemini API)
  - `Header and Module block.txt` — an alternate header/hero markup snippet
  - `LED Fundamentals/Module 1/index.html` — a real, finished module: "Diode Types" with four clickable spec cards (SMD, GOB, MIP, Flip-Chip COB) that open a detail modal with a diagram image
  - `LED Fundamentals/Module 1/{SMD,GOB,MIP,COB}.{jpg,png}` — diode-structure diagrams (dark-background technical illustrations)
  - `Ideas/` — stock/marketing imagery and video for SmartView and Smart TV features (reference only, not used to build components)
  - `Samsung-Knox-Certified-Solution-Master-1.png` — a Samsung Knox partner-certification badge (third-party program badge, not a general Samsung logo)
  - `SamsungDesign.md` — OCR'd brand colour guideline excerpt (same content as the uploaded file below)
- `uploads/SamsungDesign.md` — Samsung's official Brand Colour Guidelines: Samsung Blue, Black & White, and the seven-colour Illustrative palette.

No Figma file, component library, or production codebase was attached — everything here is reverse-engineered from the four HTML template drafts and the one finished module above, which is why the component inventory is intentionally small and literal.

## Two blues, on purpose
The uploaded brand guidelines define the **official corporate Samsung Blue** as `#1428A0` (Pantone 286C) — reserved for brand moments, logos and corporate communications. But every actual template in `eLearning/` uses a brighter **`#0062FF`** for buttons, links, focus rings and accents. Both are real and both are kept as separate tokens: `--brand-blue` (corporate identity) and `--interactive-blue` (the working UI accent actually used on screen). Default to `--interactive-blue` for UI; reach for `--brand-blue` only for brand-mark moments.

## Components
Built from the literal inventory found across the templates — nothing invented beyond what's listed under "Intentional additions."
- **Layout**: `Header`, `HeroBlock`, `LandscapeCard`
- **Content**: `Eyebrow`, `ListItem`, `ChecklistItem`, `InfoCard`
- **Forms**: `Button`, `TextareaField`
- **Feedback**: `OutputPanel`, `Modal`

**Intentional additions:** none — every component maps directly to a block found in the source HTML.

## UI Kits
- `ui_kits/elearning-module/` — interactive recreation of the Module 1 "Indoor LED Fundamentals" page: sticky header, dark hero, alternating LandscapeCards, clickable diode InfoCards → Modal, and a (mocked) AI-recommendation tool.

## Content fundamentals
- **Voice**: instructional and plain-spoken, second person ("Understanding how the lights are built helps balance durability..."). Explains *why*, not just *what* — every technical term gets a one-line consequence ("...shields them from water, dust, and bumps in busy public areas").
- **Structure**: short paragraphs (1–3 sentences), bolded lead-in terms in checklists ("**4K resolution**: ..."), a bold "Relevant Samsung Displays" callout line naming exact product series after each technical explanation — ties abstract concepts back to sellable products.
- **Casing**: sentence case for body copy and headings; eyebrow/pill labels are uppercase with tracked letter-spacing.
- **CTAs**: short, direct, verb-first ("Click to view", "Generate"). No exclamation points, no hype language.
- **Emoji**: not used in module copy. One 💡 appears in a developer-facing error hint in the template's JS console/error UI (not learner-facing copy) — treat as out of scope for content voice.
- **Tone**: professional/technical, calm, confident — a subject-matter expert briefing colleagues, not a marketing pitch.

## Visual foundations
- **Color**: near-white cool-gray surface (`#f5f7fb`) as the page background, white cards, `#0062FF` interactive accent, near-black (`#1e1e1e`) for dark hero/nav sections. Two-tone system (light content area + one dark anchor block per page) rather than colorful surfaces.
- **Type**: bold display headings (Archivo, substituted — see below) paired with a plain, high-legibility body face; generous 26px body line-height for long-form reading; eyebrow labels always uppercase with wide tracking.
- **Spacing**: an unusual, non-4/8px-uniform scale found verbatim in the source — 8 / 16 / 24 / 32 / 48px. Kept exactly as authored, not normalized.
- **Backgrounds**: flat color only — no gradients, no patterns, no textures. Photography is real estate/lifestyle stock (warm, natural light) for module hero images; technical diagrams use a dark, near-black background with saturated neon-glow accent colors (see SMD/GOB/MIP/COB diagrams).
- **Corners**: consistently large and soft — 12–24px on cards, full pill (999px) on buttons and eyebrow tags. No sharp corners anywhere in the source.
- **Cards**: white fill, 1px `#ebebed` hairline border, one soft ambient shadow (`0 16px 40px rgba(0,0,0,.06)`) — no shadow ladder, no colored borders except the 4px left-accent stripe on clickable spec cards (InfoCard).
- **Hover/press**: hover = subtle lift (`translateY(-2px)`) plus a slightly deeper shadow, or opacity drop to 0.85 on solid buttons. No color-darken hovers, no scale/bounce. Disabled state swaps fill to the neutral border-gray, no opacity trick.
- **Motion**: minimal and functional only — 0.2s ease transforms/opacity on hover, a 0.3–0.4s fade for modals and revealed result panels, a linear 1s spinner for loading. No entrance choreography, no bounce/spring easing.
- **Modals**: centered card over a `rgba(0,0,0,.6)` scrim with backdrop blur — not a slide-in drawer.
- **Transparency/blur**: only on the modal scrim and on tinted pill/badge backgrounds (e.g. `rgba(0,98,255,.1)` eyebrow fill, `rgba(255,255,255,.15)` light eyebrow on dark hero).
- **Imagery vibe**: warm, natural-light lifestyle photography for real-world context shots; cool, dark, high-contrast technical illustration style for diagrams (glowing saturated diode colors on near-black).
- **Layout rules**: single centered content column (max-width 1000px), sticky header pinned to top, alternating image-left/image-right rhythm down the page — no sidebars, no dashboards, no complex grids in the source.

## Iconography
No icon font, SVG icon set, or icon library was present anywhere in the source templates. The only "icons" found are:
- A plain Unicode checkmark (✓) for checklist items
- A Unicode ✕ for the modal close button
- Numeral chips (styled `div`s with a number, not glyphs) for step lists

**No substitution has been made** — the source simply doesn't use an icon system yet. If iconography is needed going forward (e.g. a settings/download/info glyph), the closest CDN match for this UI's plain, low-decoration style would be **Lucide** (thin-stroke, neutral) — flagging this as a suggestion, not something built in yet.

## Fonts
Real Samsung global corporate typefaces are now installed — **Samsung SS Head** (Light/Regular/Medium/Bold, app-optimized cut) for display/headings and **Samsung SS Body** (Light/Regular/Bold, app-optimized cut) for body copy, sourced from the user's font files plus the *2025 Samsung Typographic Playbook*, which confirmed these exact family names. Declared via `@font-face` in `tokens/fonts.css`, files live in `assets/fonts/`. This replaces the earlier Archivo/IBM Plex Sans placeholder substitution.

## Logo
No Samsung wordmark or logo file was included in the source. Per policy, no logo has been drawn or reconstructed — the wordmark is rendered as plain text ("SAMSUNG") in the display typeface wherever a mark is needed (see `thumbnail.html`, `Header`). The one real logo-like asset present, `assets/imported/Samsung-Knox-Certified-Solution-Master-1.png`, is a **Knox partner-certification badge**, not a general-purpose Samsung logo — kept for reference only, not used as the brand mark.

## Index
- `styles.css` — root stylesheet, imports everything under `tokens/`
- `tokens/` — `colors.css`, `typography.css`, `spacing.css`, `radii.css`, `shadows.css`, `fonts.css`
- `assets/fonts/` — real Samsung SS Head/Body app-cut font files
- `components/layout/` — Header, HeroBlock, LandscapeCard
- `components/content/` — Eyebrow, ListItem, ChecklistItem, InfoCard
- `components/forms/` — Button, TextareaField
- `components/feedback/` — OutputPanel, Modal
- `guidelines/` — foundation specimen cards (colors, type, spacing, radii, shadow, imagery)
- `ui_kits/elearning-module/` — interactive Module 1 recreation
- `assets/imported/` — diode diagrams, stock imagery, Knox badge (copied from the source folder)
- `SKILL.md` — Claude-Code-compatible skill wrapper for this design system

## Caveats & ask
- **No real component library, Figma file, or production codebase was attached** — this whole system is reverse-engineered from four overlapping HTML template drafts plus one finished module. If a Figma file or the live Rise 360 course library exists, attaching it would let this system grow far more accurately and completely.
- **No logo file exists in the source** — if there's an official Samsung Display or Samsung Display Academy lockup, attach it and it'll replace the plain-text wordmark everywhere.
- The component set is deliberately small (11 components) because that's the literal inventory in the source. **Tell me what else to build** — e.g. a quiz/assessment component, a video-lesson layout, a progress tracker, or a course-catalog/landing screen — and I'll iterate.
